from django.db import models

class Category(models.Model):
    name_category = models.CharField(max_length=255,unique=True)
    def __str__(self):
        return self.name_category
class Blogs(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    detail = models.TextField()
    category = models.ForeignKey(Category,on_delete=models.CASCADE)
    writer = models.CharField(max_length=255)
    views = models.IntegerField(default=0)
    image = models.ImageField(upload_to="blogImages",blank=True)
    created = models.DateField(auto_now_add=True)
    def __str__(self):
        return self.title
class Courses(models.Model):
    namecourses = models.CharField(max_length=400)
    descriptioncourses = models.TextField()
    detailcourses = models.TextField()
    imagecourses = models.ImageField(upload_to="coureseImages",blank=True)
    def __str__(self):
        return self.namecourses

class ContactMessage(models.Model):
    titlemessage = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    detailmessage = models.TextField(blank=True,null=True)
    def __str__(self):
        return self.titlemessage
