from  django.urls import path
from .views import*

urlpatterns = [
    path('',index),
    path('About',About,name='About'),
    path('CoursesOnline',CoursesOnline,name='CoursesOnline'),
    path('blog/<int:id>',blogDetail,name="blogDetail"),
    path('courses/<str:id>',CoursesOnlineDetail,name="CoursesOnlineDetail"),
    path('Contact',Contact,name='Contact'),
    path('Services',Services,name='Services'),    
]
