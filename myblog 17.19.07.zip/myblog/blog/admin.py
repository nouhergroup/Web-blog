from django.contrib import admin
from django_summernote.admin import SummernoteModelAdmin
from .models import*
admin.site.register(Category)

class BlogAdmin(SummernoteModelAdmin):
    summernote_fields = ('detail',)

admin.site.register(Blogs,BlogAdmin)

class CourseAdmin(SummernoteModelAdmin):
    summernote_fields = ('detailcourses','descriptioncourses')

admin.site.register(Courses,CourseAdmin)


admin.site.register(ContactMessage)


