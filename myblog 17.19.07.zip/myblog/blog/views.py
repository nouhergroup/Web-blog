import contextlib
from typing import ContextManager
from django.shortcuts import render
from .models import*
from django.core.paginator import InvalidPage, Paginator, EmptyPage, InvalidPage

def index(request):
    categories = Category.objects.all()
    blogs = Blogs.objects.all()
    latest = Blogs.objects.all().order_by('pk')
    paginator = Paginator(blogs,6)
    popular = Blogs.objects.all().order_by('views')[:4]
    try:
        page = int(request.GET.get('page','1'))
    except:
        page = 1
    try:
        blogPerpage = paginator.page(page)
    except(EmptyPage,InvalidPage):
        blogPerpage = paginator.page(paginator.num_pages)

    return render(request,"frontend/index.html",{'categories':categories,'blogs':blogs,'latest':latest,'blogs':blogPerpage,'popular':popular})

def blogDetail(request,id):
    if request.method == "POST":
        data = request.POST.copy()
        titlemessage = data.get('titlemessage')
        email = data.get('email')
        detailmessage = data.get('detailmessage')
       # print(titlemessage,email,detailmessage)
        new = ContactMessage()
        new.titlemessage = titlemessage
        new.email = email
        new.detailmessage = detailmessage
        new.save()
   
        
    singleBlog = Blogs.objects.get(id=id)
    singleBlog.views = singleBlog.views+1
    singleBlog.save()
    return render(request,"frontend/blogDetail.html",{"blog":singleBlog})



def About(request):

    return render(request,"frontend/about.html")

def CoursesOnline(request):
    courses = Courses.objects.all()
    Pg = Paginator(Courses,10)



    return render(request,"frontend/courses.html",{'courses':courses,Pg:Pg})


def CoursesOnlineDetail(request,id):
    singlecourse = Courses.objects.get(id=id)
    singlecourse.save()
    return render(request,"frontend/coursesdetail.html",{"course":singlecourse})

def Contact(request):

    return render(request,"frontend/Contact.html")

def Services(request):

    return render(request,"frontend/Services.html")